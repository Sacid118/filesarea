import Files from "./components/Files.vue";

panel.plugin("Trigga28/filesarea", {
  components: {
    "k-files-view": Files
  }
});
